package Programa;

public class Disciplinas {

    private String disciplinas;

    public Disciplinas(String disciplinas){

        this.disciplinas = disciplinas;
    }

    public String getDisciplinas() {
        return disciplinas;
    }

    public void setDisciplinas(String disciplinas) {
        this.disciplinas = disciplinas;
    }

}
