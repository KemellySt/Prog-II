package Programa;

public class Funcionario {

    Pessoa pessoa;
    String ctps;
    Double salario;

    void mostrarFuncionario(){

        System.out.println("Funcionário: " + this.pessoa.nome);
        System.out.println("Endereço: " + this.pessoa.endereco);
        System.out.println("Telefone: " + this.pessoa.telefone);
        System.out.println("CPF: " + this.pessoa.cpf);
        System.out.println("Salário: " + this.salario);
        System.out.println("CTPS: " + this.ctps);
    }

}
