package Programa;
public class Aluno {
    
    Pessoa pessoa;
    String matricula;
    Curso curso;

    void mostrarAluno(){

            System.out.println("Nome: " + this.pessoa.nome);
            System.out.println("Matrícula: " + this.matricula);
            System.out.println("Endereço: " + this.pessoa.endereco);
            System.out.println("Telefone:\n" + this.pessoa.telefone);
            System.out.println("Curso: " + this.curso.nomeDocurso);

        }
}
