package Programa;

public class Main {
    public static void main(String[] args) throws Exception {

        // Kemelly Steisse da Silva - 23.1.8111

        // Organizando a tela inicial
        System.out.println("-----------------------------------------Universidade Federal de Ouro Preto------------------------------------\n");

                System.out.println("\n--------------------------------------------CADASTRAMENTO DE ALUNOS--------------------------------------------");
                // Pessoa
                Pessoa p1 = new Pessoa();
                p1.nome = "Kemelly Steisse da Silva";
                p1.endereco = "Minas Gerais, João Monlevade, rua Alfredo Oliveira, número 50";
                p1.telefone = "31 98945- 3246";

                Pessoa p2 = new Pessoa();
                p2.nome = "Jéssica";
                p2.endereco = "Minas Gerais, João Pinheiros, rua Astrofo Dutra, número 450";
                p2.telefone = "31 8756-4523";
                p2.cpf = "143.654.754-10";

                // Curso
                Curso c;
                c = new Curso();  
                    
                    c.nomeDocurso = "Engenharia da Computação";
                    c.disciplinas = "1 - Matemática Discreta\n2 - Cálculo II\n3 - Programação de Computadores II\n4 - Física I";
                    c.codigo = 40028922;
                    c.descricao = "...";

                // Aluno
                Aluno a = new Aluno();
                
                    a.pessoa = p1;
                    a.matricula = "23.1.8117";
                    a.curso = c;

                //Funcionário
                Funcionario f;
                f = new Funcionario();

                    f.pessoa = p2;
                    f.salario = 3000.00;
                    f.ctps = "234573";

                // Imprimindo todos as informações
                System.err.println("----------------------------------INFORMAÇÕES--------------------------------");
                System.err.print("\n");
                System.out.print("Dados Aluno\n");
                System.err.print("\n");
                a.mostrarAluno();
                System.err.print("\n");

                System.out.print("Dados Curso\n");
                System.err.print("\n");
                c.mostrarCurso();
                System.err.print("\n");

                System.err.print("Dados Funcionário\n");
                System.out.print("\n");
                f.mostrarFuncionario();

    }
}
