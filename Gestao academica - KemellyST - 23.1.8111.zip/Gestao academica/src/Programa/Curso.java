package Programa;

public class Curso {

    String nomeDocurso;
    String disciplinas;
    int codigo;
    String descricao;

    void mostrarCurso(){

        System.out.println("Nome do curso: " + this.nomeDocurso);
        System.out.println("Disciplinas\n" + this.disciplinas);
        System.out.println("Codigo: " + this.codigo);
        System.out.println("Descrição:\n" + this.descricao);

    }
}