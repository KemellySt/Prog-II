package Programa;

public class Pessoa{

    String nome;
    String endereco;
    String telefone;
    String cpf;
}