package Programa;

public class Professor {
    
    String titualacao;
    String areaP;
    Funcionario nome;
    Curso disciplinas;
    Funcionario endereço;
    Funcionario telefone;
    Funcionario cpf;

}
